package com.example.activity7and8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
