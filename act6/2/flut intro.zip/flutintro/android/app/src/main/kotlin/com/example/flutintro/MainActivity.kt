package com.example.flutintro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
